public class p1e2
{
	public static void main(String[] args) {
		System.out.println("Your first argument is: "+args[0]);
	}
}
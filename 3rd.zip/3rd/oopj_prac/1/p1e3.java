import java.util.Scanner;
public class p1e3
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter value of a through Scanner");
		int a=sc.nextInt();
		System.out.println("You entered value through Scanner is :"+a);
	}
}
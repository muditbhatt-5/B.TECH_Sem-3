import java.util.*;
public class p4e4
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String:");
		String st = sc.next();
		int leng = st.length();
		int half = leng / 2;
		System.out.println("Length of String is:"+leng);
		System.out.println("half length of String:"+half);
	}
}
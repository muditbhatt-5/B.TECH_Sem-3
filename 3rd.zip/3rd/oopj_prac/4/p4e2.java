import java.util.*;
public class p4e2
{
	public static void main(String[] args) {
		int[] a = new int[]{50,50,60,40};
		int sum=0;
		for(int i=0;i<a.length;i++)
		{
			sum = sum + a[i];
		}
		double avg = sum / a.length;
		System.out.println("Average is:"+avg);
	}
}
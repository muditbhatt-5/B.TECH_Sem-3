import java.util.*;
public class p4e3
{
	public static void main(String[] args) {
		int[] a=new int[]{10,20,3,40,60,90};
		for(int i=a.length-1;i>=0;i--)
		{
			System.out.println(a[i]+"");
		}
	}
}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5 mb-3">Logout</h2>
                   
                        <div class="alert alert-danger">
                            <input type="hidden" name="hidden"/>
                            <p>Are you sure you want to Logout?</p>
                            <p>
                               
                                <a href="../demo/index.php" class="btn btn-secondary">Yes</a> 
                                <a href="index.php" class="btn btn-secondary">No</a>
                            </p>
                        </div>
                    
                </div>
            </div>        
        </div>
    </div>
</body>
</html>
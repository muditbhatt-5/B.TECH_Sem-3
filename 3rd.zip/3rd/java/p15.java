import javax.swing.*;
import java.awt.*;
/*<applet code="p15" height=400 width=400></applet>*/
public p15 extends JApplet
{
	String Country[]={"india","pak","canada"}	
	public void  init()
	{
		setLayout(new FlowLayout());
		ImageIcon icon=new ImageIcon("");

		JTextField F=new JTextField("Enter Your Password",20);

	}
}
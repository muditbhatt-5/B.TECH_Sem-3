class escape
{
	public static void main(String[] args) {
		System.out.println("Good Morning ");
		System.out.println("\r ");
	}
}
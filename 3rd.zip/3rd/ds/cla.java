import java.util.*;
public class cla
{
    public static void main(String[] args)
    {
        System.out.println("args1"+args[0]);
        System.out.println("args1"+args[1]);
    }
}